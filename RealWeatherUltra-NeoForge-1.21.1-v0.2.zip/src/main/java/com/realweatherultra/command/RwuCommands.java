package com.realweatherultra.command;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.realweatherultra.RealWeatherUltra;
import com.realweatherultra.core.CloudType;
import com.realweatherultra.radar.RadarService;
import com.realweatherultra.tornado.TornadoEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /rwu tornado          - a tornado on the ground at your position (op)
 * /rwu storm            - a storm 0 blocks from you that grows and may spawn a tornado (op)
 * /rwu cloud list       - parameters of every cloud family
 * /rwu radar <lat> <lon> - current precipitation, conditions and wind from Visual Crossing
 */
public class RwuCommands {

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("rwu")
                .then(Commands.literal("tornado")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> spawnTornado(ctx.getSource())))
                .then(Commands.literal("storm")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> spawnStorm(ctx.getSource())))
                .then(Commands.literal("cloud")
                        .then(Commands.literal("list")
                                .executes(ctx -> listClouds(ctx.getSource()))))
                .then(Commands.literal("radar")
                        .then(Commands.argument("lat", DoubleArgumentType.doubleArg(-90.0, 90.0))
                                .then(Commands.argument("lon", DoubleArgumentType.doubleArg(-180.0, 180.0))
                                        .executes(ctx -> radar(ctx.getSource(),
                                                DoubleArgumentType.getDouble(ctx, "lat"),
                                                DoubleArgumentType.getDouble(ctx, "lon")))))));
    }

    private static int spawnTornado(CommandSourceStack src) {
        ServerLevel level = src.getLevel();
        Vec3 p = src.getPosition();
        int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (int) Math.floor(p.x), (int) Math.floor(p.z));
        TornadoEntity t = new TornadoEntity(RealWeatherUltra.TORNADO.get(), level);
        t.setPos(p.x, groundY, p.z);
        level.addFreshEntity(t);
        src.sendSuccess(() -> Component.literal("Торнадо создано"), true);
        return 1;
    }

    private static int spawnStorm(CommandSourceStack src) {
        Vec3 p = src.getPosition();
        RealWeatherUltra.STORMS.spawnStormAt(p.x, p.z);
        src.sendSuccess(() -> Component.literal("Шторм создан. Активных штормов: " + RealWeatherUltra.STORMS.count()), true);
        return 1;
    }

    private static int listClouds(CommandSourceStack src) {
        for (CloudType type : CloudType.values()) {
            String line = type.name() + ": высота " + (int) type.baseY + "-" + (int) type.topY + " блоков";
            src.sendSuccess(() -> Component.literal(line), false);
        }
        return CloudType.values().length;
    }

    private static int radar(CommandSourceStack src, double lat, double lon) {
        var server = src.getServer();
        RadarService.describe(lat, lon).thenAccept(text ->
                server.execute(() -> src.sendSuccess(() -> Component.literal(text), false)));
        return 1;
    }
}
