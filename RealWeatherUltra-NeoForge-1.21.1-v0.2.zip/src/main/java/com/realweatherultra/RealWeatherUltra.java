package com.realweatherultra;

import com.realweatherultra.command.RwuCommands;
import com.realweatherultra.storm.StormManager;
import com.realweatherultra.tornado.TornadoEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(RealWeatherUltra.MODID)
public class RealWeatherUltra {
    public static final String MODID = "realweatherultra";

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<TornadoEntity>> TORNADO =
            ENTITY_TYPES.register("tornado", () -> EntityType.Builder.<TornadoEntity>of(TornadoEntity::new, MobCategory.MISC)
                    .sized(4.0f, 12.0f)
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .fireImmune()
                    .build("tornado"));

    /** All storms in the overworld. Lives only in memory, cleared on server restart. */
    public static final StormManager STORMS = new StormManager();

    public RealWeatherUltra(IEventBus modBus) {
        ENTITY_TYPES.register(modBus);
        NeoForge.EVENT_BUS.register(STORMS);
        NeoForge.EVENT_BUS.register(new RwuCommands());
    }
}
