package com.realweatherultra.radar;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Current precipitation, conditions and wind for a point, from the Visual Crossing Timeline API
 * (no key required, free-tier limits apply). Results are cached for 10 minutes.
 * Weather data must be shown with attribution: the text returned here includes it.
 */
public final class RadarService {
    private static final String BASE =
            "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
    private static final long TTL_MS = 10L * 60L * 1000L;
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private static final Map<String, Cached> CACHE = new ConcurrentHashMap<>();

    private record Cached(long time, String text) {}

    private RadarService() {}

    public static CompletableFuture<String> describe(double lat, double lon) {
        String key = String.format(Locale.ROOT, "%.2f,%.2f", lat, lon);
        Cached cached = CACHE.get(key);
        if (cached != null && System.currentTimeMillis() - cached.time() < TTL_MS) {
            return CompletableFuture.completedFuture(cached.text());
        }
        String url = BASE + key
                + "?unitGroup=metric&include=current&elements=datetime,precip,conditions,windspeed&contentType=json";
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(15))
                .GET()
                .build();
        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(resp -> {
                    if (resp.statusCode() == 429) {
                        return "Лимит бесплатного API Visual Crossing исчерпан, попробуйте позже.";
                    }
                    if (resp.statusCode() != 200) {
                        return "Ошибка API Visual Crossing: HTTP " + resp.statusCode();
                    }
                    String text = parse(resp.body());
                    CACHE.put(key, new Cached(System.currentTimeMillis(), text));
                    return text;
                })
                .exceptionally(e -> "Не удалось получить данные радара: " + e.getMessage());
    }

    static String parse(String body) {
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonObject current = root.getAsJsonObject("currentConditions");
        if (current == null) return "Нет данных о текущей погоде в этой точке.";
        String precip = text(current, "precip");
        String conditions = text(current, "conditions");
        String wind = text(current, "windspeed");
        return "Радар: осадки " + precip + " мм, " + conditions + ", ветер " + wind
                + " км/ч. Weather data provided by Visual Crossing Weather";
    }

    private static String text(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "н/д";
    }
}
