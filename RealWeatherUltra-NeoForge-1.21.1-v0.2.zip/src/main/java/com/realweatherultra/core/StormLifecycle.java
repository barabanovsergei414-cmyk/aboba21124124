package com.realweatherultra.core;

/**
 * Simplified storm growth. This is NOT a CM1 solver and does not integrate the atmosphere.
 * Growth is driven by a dimensionless energy index built from CAPE, shear and humidity,
 * each normalised to 0..1. Stage thresholds are fixed and documented.
 */
public final class StormLifecycle {

    public enum Stage {
        SMALL_CUMULUS, TOWERING_CUMULUS, CUMULONIMBUS, ROTATING_UPDRAFT, WALL_CLOUD, ANVIL, MATURE, DECAYING
    }

    private double intensity;   // 0 = small cumulus, 1 = mature supercell
    private boolean decaying;

    public StormLifecycle(double initialIntensity) {
        this.intensity = clamp01(initialIntensity);
    }

    public double intensity() { return intensity; }

    /**
     * Advances the storm by dt seconds.
     * @param cape   0..1, instability (CAPE / reference)
     * @param shear  0..1, deep-layer shear (normalised 0..40 m/s)
     * @param humid  0..1, low-level moisture
     * @param cin    0..1, cap strength (higher suppresses growth)
     */
    public void step(double dt, double cape, double shear, double humid, double cin) {
        double energy = clamp01(cape) * clamp01(shear) * clamp01(humid) * (1.0 - clamp01(cin));
        if (!decaying) {
            double rate = 0.002 + 0.02 * energy;        // per second, in index units
            intensity += rate * dt * (1.0 - intensity);
            if (energy < 0.05 && intensity > 0.5) decaying = true;
        } else {
            intensity -= 0.01 * dt;
        }
        intensity = clamp01(intensity);
    }

    public Stage stage() {
        if (decaying && intensity < 0.9) return Stage.DECAYING;
        if (intensity < 0.12) return Stage.SMALL_CUMULUS;
        if (intensity < 0.28) return Stage.TOWERING_CUMULUS;
        if (intensity < 0.42) return Stage.CUMULONIMBUS;
        if (intensity < 0.54) return Stage.ROTATING_UPDRAFT;
        if (intensity < 0.66) return Stage.WALL_CLOUD;
        if (intensity < 0.80) return Stage.ANVIL;
        return Stage.MATURE;
    }

    /** Anvil visibility 0..1: the wing grows in only after the tower is established. */
    public double anvilAmount() {
        return smooth(0.55, 0.85, intensity);
    }

    static double clamp01(double v) { return Math.max(0.0, Math.min(1.0, v)); }
    static double smooth(double a, double b, double x) {
        double t = clamp01((x - a) / (b - a));
        return t * t * (3.0 - 2.0 * t);
    }
}
