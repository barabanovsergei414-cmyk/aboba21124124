package com.realweatherultra.core;

/**
 * Independent supercell shape parameters, in blocks unless noted.
 * The defaults describe a mature supercell: a narrow updraft under a wide, flat, long anvil.
 */
public record StormParams(
        double anvilLength,       // downwind extent of the anvil
        double anvilWidth,        // crosswind half-width at the widest point
        double anvilThickness,    // plate thickness where it leaves the tower
        double anvilWindShear,    // downwind drift of the plate per block of height above its base
        double anvilEdgeErosion,  // 0..1, ragged edge amount (0 = smooth)
        double updraftWidth,      // diameter of the rising tower core
        double overshootingTopHeight, // dome above the anvil top
        double horizontalScale,   // multiplies all horizontal sizes
        double verticalScale      // multiplies all heights
) {
    public static StormParams defaults() {
        return new StormParams(260, 110, 26, 0.35, 0.25, 34, 14, 1.0, 1.0);
    }

    /** Throws if the values would produce a shape that does not read as a supercell. */
    public StormParams validated() {
        require(anvilLength > 0, "anvilLength");
        require(anvilWidth > 0, "anvilWidth");
        require(anvilThickness > 0, "anvilThickness");
        require(anvilWindShear >= 0 && anvilWindShear <= 2, "anvilWindShear");
        require(anvilEdgeErosion >= 0 && anvilEdgeErosion <= 1, "anvilEdgeErosion");
        require(updraftWidth > 0, "updraftWidth");
        require(overshootingTopHeight >= 0, "overshootingTopHeight");
        require(horizontalScale > 0, "horizontalScale");
        require(verticalScale > 0, "verticalScale");
        return this;
    }

    /** Scaled copy: horizontal and vertical multipliers applied to every size. */
    public StormParams scaled() {
        double h = horizontalScale, v = verticalScale;
        return new StormParams(anvilLength * h, anvilWidth * h, anvilThickness * v, anvilWindShear,
                anvilEdgeErosion, updraftWidth * h, overshootingTopHeight * v, 1.0, 1.0);
    }

    private static void require(boolean ok, String name) {
        if (!ok) throw new IllegalArgumentException("Invalid storm parameter: " + name);
    }
}
