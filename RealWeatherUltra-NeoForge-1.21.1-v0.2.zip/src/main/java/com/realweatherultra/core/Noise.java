package com.realweatherultra.core;

/** Deterministic value noise and fBm. Pure math, no Minecraft dependencies. */
public final class Noise {
    private Noise() {}

    static double hash(int x, int y, int z, int seed) {
        int h = x * 374761393 + y * 668265263 + z * 1442695041 + seed * 1013904223;
        h = (h ^ (h >>> 13)) * 1274126177;
        h = h ^ (h >>> 16);
        return (h & 0x7fffffff) / (double) 0x7fffffff;
    }

    static double smooth(double t) {
        return t * t * (3.0 - 2.0 * t);
    }

    /** Value noise in [0,1]. */
    public static double value3(double x, double y, double z, int seed) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y), z0 = (int) Math.floor(z);
        double tx = smooth(x - x0), ty = smooth(y - y0), tz = smooth(z - z0);
        double c000 = hash(x0, y0, z0, seed), c100 = hash(x0 + 1, y0, z0, seed);
        double c010 = hash(x0, y0 + 1, z0, seed), c110 = hash(x0 + 1, y0 + 1, z0, seed);
        double c001 = hash(x0, y0, z0 + 1, seed), c101 = hash(x0 + 1, y0, z0 + 1, seed);
        double c011 = hash(x0, y0 + 1, z0 + 1, seed), c111 = hash(x0 + 1, y0 + 1, z0 + 1, seed);
        double a = lerp(lerp(c000, c100, tx), lerp(c010, c110, tx), ty);
        double b = lerp(lerp(c001, c101, tx), lerp(c011, c111, tx), ty);
        return lerp(a, b, tz);
    }

    /** Fractal sum of value noise, normalised to [0,1]. */
    public static double fbm3(double x, double y, double z, int octaves, int seed) {
        double sum = 0, amp = 0.5, norm = 0, f = 1.0;
        for (int i = 0; i < octaves; i++) {
            sum += amp * value3(x * f, y * f, z * f, seed + i * 17);
            norm += amp;
            amp *= 0.5;
            f *= 2.03;
        }
        return norm == 0 ? 0 : sum / norm;
    }

    static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }
}
