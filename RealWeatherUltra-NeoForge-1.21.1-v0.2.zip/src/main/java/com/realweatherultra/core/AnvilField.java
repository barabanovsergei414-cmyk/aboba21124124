package com.realweatherultra.core;

/**
 * Analytic supercell anvil and tower. Coordinates: x = downwind (blocks, tower axis at 0),
 * z = crosswind, y = height above the storm base. Returns a density in [0,1].
 * The model: a flat top and a near-flat base, a long downwind wing, edges that taper and erode,
 * a tower core under the anvil and a small overshooting dome above the anvil top.
 */
public final class AnvilField {
    private final StormParams p;
    private final double towerTop;     // height where the anvil base starts
    private final double anvilBase;
    private final double anvilTop;
    private final int seed;

    public AnvilField(StormParams params, double stormHeight, int seed) {
        this.p = params.validated().scaled();
        this.seed = seed;
        this.towerTop = stormHeight * 0.80;
        this.anvilBase = stormHeight * 0.82;
        this.anvilTop = stormHeight;
    }

    public double anvilBase() { return anvilBase; }
    public double anvilTop() { return anvilTop; }
    public StormParams params() { return p; }

    /** Plate base at downwind position u (0..1 along the wing): nearly flat, slightly lower far out. */
    double baseAt(double u) {
        return anvilBase - 3.0 * u * u;
    }

    /** Plate top at u: flat, with a very small sag at the far end. */
    double topAt(double u) {
        return anvilTop - 1.0 * u * u * u;
    }

    /** Half-width of the wing at u: full width in the middle, tapering to a thin tip. */
    double halfWidthAt(double u) {
        double t = Math.max(0.0, 1.0 - u * u);
        return 0.5 * p.anvilWidth() * Math.sqrt(t);
    }

    public double density(double x, double y, double z) {
        double tower = towerDensity(x, y, z);
        double anvil = anvilDensity(x, y, z);
        return Math.max(tower, anvil);
    }

    double towerDensity(double x, double y, double z) {
        double r = Math.hypot(x, z);
        double half = p.updraftWidth() * 0.5;
        if (y > anvilTop + p.overshootingTopHeight()) return 0.0;
        if (y > anvilTop) {
            // overshooting dome: a small round top above the anvil
            double dy = (y - anvilTop) / Math.max(1e-6, p.overshootingTopHeight());
            double rr = r / half;
            return smoothEdge(1.0 - Math.hypot(rr, dy) * 1.0);
        }
        if (y < 0 || y > towerTop + 4.0) return 0.0;
        // a narrow updraft; it flares slightly where it meets the anvil
        double flare = 1.0 + 0.25 * Math.max(0, (y - (anvilBase - 25.0)) / 25.0);
        double edge = (half * flare - r) / 6.0;
        return smoothEdge(edge);
    }

    double anvilDensity(double x, double y, double z) {
        // wind shear pushes the plate downwind as it rises
        double shift = p.anvilWindShear() * Math.max(0.0, y - anvilBase);
        double xa = x - shift;
        double x0 = -0.3 * p.updraftWidth();
        double span = p.anvilLength();
        double u = (xa - x0) / span;
        if (u < 0.0 || u > 1.0) return 0.0;

        double yb = baseAt(u), yt = topAt(u);
        double vertical = Math.min((y - yb) / 4.0, (yt - y) / 3.0);
        if (vertical <= 0) return 0.0;

        double hw = halfWidthAt(u);
        double erosion = p.anvilEdgeErosion() * 0.5
                * Noise.fbm3(xa / 40.0, y / 20.0, z / 40.0, 3, seed + 101);
        double edge = (hw * (1.0 - erosion) - Math.abs(z)) / 4.0;
        if (edge <= 0) return 0.0;

        // thin tip at the far end, thicker near the tower
        double thick = p.anvilThickness() * (1.0 - 0.6 * u);
        double vert = Math.min(1.0, vertical / Math.max(1.0, thick * 0.25));
        return Math.min(1.0, smoothEdge(edge) * vert);
    }

    static double smoothEdge(double d) {
        return Math.max(0.0, Math.min(1.0, 0.5 + 0.5 * d));
    }
}
