package com.realweatherultra.core;

/**
 * Cloud families. Each has its own height band, shape scale, coverage and detail.
 * density() = height profile * fBm of a domain-warped position. Values are in [0,1].
 */
public enum CloudType {
    //              baseY  topY  hScale  vScale  coverage  erosion
    CIRRUS         (7000, 9000, 900.0, 40.0, 0.35, 0.8),
    STRATUS        (300, 700, 500.0, 60.0, 0.55, 0.3),
    STRATOCUMULUS  (500, 1000, 260.0, 90.0, 0.50, 0.5),
    CUMULUS        (400, 1400, 160.0, 140.0, 0.45, 0.6),
    TOWERING_CUMULUS(400, 2600, 220.0, 180.0, 0.40, 0.5),
    CUMULONIMBUS   (400, 3800, 320.0, 220.0, 0.35, 0.4);

    public final double baseY, topY, hScale, vScale, coverage, erosion;

    CloudType(double baseY, double topY, double hScale, double vScale, double coverage, double erosion) {
        this.baseY = baseY;
        this.topY = topY;
        this.hScale = hScale;
        this.vScale = vScale;
        this.coverage = coverage;
        this.erosion = erosion;
    }

    /** Density at world position (x, y, z) for this cloud family. */
    public double density(double x, double y, double z, int octaves, int seed) {
        if (y < baseY || y > topY) return 0.0;
        double h = (y - baseY) / (topY - baseY);
        // flat base, rounded top: density rises fast above the base and falls off near the top
        double profile = smoothStep(0.0, 0.12, h) * (1.0 - smoothStep(0.55, 1.0, h));
        if (this == CIRRUS) profile = smoothStep(0.0, 0.3, h) * (1.0 - smoothStep(0.6, 1.0, h));

        // domain warp: bends the shape so it does not look like noise
        double wx = (Noise.fbm3(x / hScale, y / vScale, z / hScale, 2, seed + 7) - 0.5) * 0.6;
        double wz = (Noise.fbm3(x / hScale + 3.1, y / vScale, z / hScale - 1.7, 2, seed + 9) - 0.5) * 0.6;
        double n = Noise.fbm3((x + wx * hScale) / hScale, y / vScale, (z + wz * hScale) / hScale, octaves, seed);

        // coverage threshold: above it the cloud exists, lower coverage = fewer, smaller masses
        double d = (n - (1.0 - coverage)) / Math.max(0.05, erosion * 0.5);
        double raw = profile * Math.max(0.0, Math.min(1.0, d));
        return Math.max(0.0, Math.min(1.0, raw));
    }

    static double smoothStep(double a, double b, double x) {
        double t = Math.max(0.0, Math.min(1.0, (x - a) / (b - a)));
        return t * t * (3.0 - 2.0 * t);
    }
}
