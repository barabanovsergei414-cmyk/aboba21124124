package com.realweatherultra.core;

/** Quality presets. Values are used by the cloud renderer and must be applied as shader uniforms. */
public enum QualityPreset {
    LOW(24, 3, 3, 0.5, 1800),
    MEDIUM(40, 4, 4, 0.75, 3500),
    HIGH(64, 5, 5, 1.0, 5500),
    ULTRA(96, 6, 6, 1.0, 7500);

    /** Primary march steps through a cloud layer. */
    public final int raySteps;
    /** Light (sun) steps per primary sample. */
    public final int lightSteps;
    /** Noise octaves for cloud detail. */
    public final int noiseOctaves;
    /** Cloud render resolution scale (1.0 = full). */
    public final double resolutionScale;
    /** Clouds fade out beyond this distance, in blocks. */
    public final double maxDistance;

    QualityPreset(int raySteps, int lightSteps, int noiseOctaves, double resolutionScale, double maxDistance) {
        this.raySteps = raySteps;
        this.lightSteps = lightSteps;
        this.noiseOctaves = noiseOctaves;
        this.resolutionScale = resolutionScale;
        this.maxDistance = maxDistance;
    }
}
