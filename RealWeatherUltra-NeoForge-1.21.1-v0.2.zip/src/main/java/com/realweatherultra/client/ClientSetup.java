package com.realweatherultra.client;

import com.realweatherultra.RealWeatherUltra;
import com.realweatherultra.tornado.TornadoEntity;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** The tornado is drawn with particles from the server, so its entity renderer draws no model. */
@EventBusSubscriber(modid = RealWeatherUltra.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(RealWeatherUltra.TORNADO.get(), TornadoRenderer::new);
    }

    public static class TornadoRenderer extends EntityRenderer<TornadoEntity> {
        public TornadoRenderer(EntityRendererProvider.Context context) {
            super(context);
        }

        @Override
        public ResourceLocation getTextureLocation(TornadoEntity entity) {
            return ResourceLocation.withDefaultNamespace("textures/misc/white.png");
        }
    }
}
