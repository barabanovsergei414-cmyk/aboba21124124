package com.realweatherultra.storm;

import com.realweatherultra.RealWeatherUltra;
import com.realweatherultra.core.StormLifecycle;
import com.realweatherultra.tornado.TornadoEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;

/** One storm: grows with StormLifecycle and makes a tornado under its tower once it is rotating. */
public final class Storm {
    private final StormLifecycle lifecycle;
    private double x;
    private double z;
    private int ageTicks;
    private TornadoEntity tornado;

    public Storm(double x, double z, double initialIntensity) {
        this.x = x;
        this.z = z;
        this.lifecycle = new StormLifecycle(initialIntensity);
    }

    public StormLifecycle.Stage stage() { return lifecycle.stage(); }
    public double intensity() { return lifecycle.intensity(); }
    public double x() { return x; }
    public double z() { return z; }
    public int ageTicks() { return ageTicks; }

    /** Called once per second of game time. */
    public void update(ServerLevel level) {
        // Fixed favourable conditions until real weather data is wired in.
        lifecycle.step(1.0, 0.8, 0.8, 0.8, 0.1);
        x += 0.5;          // wind drift, blocks per second
        ageTicks += 20;
        if (tornado != null && tornado.isRemoved()) tornado = null;
        boolean rotating = lifecycle.stage().ordinal() >= StormLifecycle.Stage.ROTATING_UPDRAFT.ordinal();
        if (rotating && tornado == null && level.random.nextDouble() < 0.05) {
            spawnTornado(level);
        }
    }

    private void spawnTornado(ServerLevel level) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        if (!level.hasChunkAt(new BlockPos(bx, 0, bz))) return;
        int groundY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, bx, bz);
        TornadoEntity t = new TornadoEntity(RealWeatherUltra.TORNADO.get(), level);
        t.setPos(x, groundY, z);
        t.setDrift(0.05, 0.0);
        if (level.addFreshEntity(t)) tornado = t;
    }

    public boolean isFinished() {
        return lifecycle.stage() == StormLifecycle.Stage.DECAYING && lifecycle.intensity() < 0.05;
    }
}
