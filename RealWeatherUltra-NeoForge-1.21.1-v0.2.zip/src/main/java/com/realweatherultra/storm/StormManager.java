package com.realweatherultra.storm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Spawns storms during thunder near players and advances all storms once per second. */
public final class StormManager {
    private static final int MAX_NATURAL_STORMS = 3;
    private final List<Storm> storms = new ArrayList<>();

    @SubscribeEvent
    public void onLevelTick(LevelTickEvent.Post event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;
        if (level.getGameTime() % 20 != 0) return;
        if (level.players().isEmpty()) return;

        if (level.isThundering() && storms.size() < MAX_NATURAL_STORMS && level.random.nextDouble() < 0.02) {
            ServerPlayer p = level.players().get(level.random.nextInt(level.players().size()));
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            double dist = 150.0 + level.random.nextDouble() * 250.0;
            storms.add(new Storm(p.getX() + Math.cos(angle) * dist, p.getZ() + Math.sin(angle) * dist, 0.05));
        }

        Iterator<Storm> it = storms.iterator();
        while (it.hasNext()) {
            Storm s = it.next();
            s.update(level);
            if (s.isFinished()) it.remove();
        }
    }

    /** Creates a storm already in its mature-ish stage (used by /rwu storm). */
    public Storm spawnStormAt(double x, double z) {
        Storm s = new Storm(x, z, 0.6);
        storms.add(s);
        return s;
    }

    public int count() { return storms.size(); }
}
